//
// Created by gonca on 30/11/2023.
//

#ifndef TRABALHO_AED_LP_1_AED_LP1_PROJ_H
#define TRABALHO_AED_LP_1_AED_LP1_PROJ_H

// Estrutura para armazenar palavra e seu código UFP6
typedef struct {
    char *word;
    char *ufp6Code;
    char *binaryRepresentation;
} WordEntry;

// Estrutura para armazenar conjunto de palavras e códigos UFP6
typedef struct {
    WordEntry **entries;
    size_t rows;
    size_t cols;
} WordMatrix;



char* wordToBinary(const char *word);

char* charTo6BitBinary(char c);//passa o binario apenas para 6 bits

int main_aed_lp_proj();
#endif //TRABALHO_AED_LP_1_AED_LP1_PROJ_H
