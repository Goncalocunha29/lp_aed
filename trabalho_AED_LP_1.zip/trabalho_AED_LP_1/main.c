#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "AED_LP1_proj.h"

int main() {
    main_aed_lp_proj();
    return 0;
}

